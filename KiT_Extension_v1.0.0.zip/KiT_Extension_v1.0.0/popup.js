// ═══════════════════════════════════════════════════════════
//  KiT Tools Downloader — Popup Script
// ═══════════════════════════════════════════════════════════

const $ = (id) => document.getElementById(id);

const dot       = $("dot");
const statusTxt = $("statusTxt");
const toast     = $("toast");
const tEnabled  = $("tEnabled");
const tVideo    = $("tVideo");
const tAudio    = $("tAudio");
const tFiles    = $("tFiles");

let syncingUi = false;

function computeMasterState(s) {
  return !!(s.interceptDownloads || s.interceptVideos || s.interceptAudio || s.interceptFiles);
}

function applyUiState(s) {
  syncingUi = true;
  if (tEnabled) tEnabled.checked = computeMasterState(s);
  if (tVideo) tVideo.checked = s.interceptVideos !== false;
  if (tAudio) tAudio.checked = s.interceptAudio !== false;
  if (tFiles) tFiles.checked = s.interceptFiles !== false;
  syncingUi = false;
}

// ══════════════════════════════════════════════════════════
//  تحميل الإعدادات الحالية وعرضها
// ══════════════════════════════════════════════════════════
chrome.runtime.sendMessage({ type: "get-settings" }, (resp) => {
  if (chrome.runtime.lastError || !resp?.settings) return;
  const s = resp.settings;
  applyUiState(s);
});

// ══════════════════════════════════════════════════════════
//  حفظ تغييرات الإعدادات
// ══════════════════════════════════════════════════════════
function saveSettings(settings) {
  chrome.runtime.sendMessage({
    type: "set-settings",
    settings,
  });
}

if (tEnabled) {
  tEnabled.addEventListener("change", () => {
    if (syncingUi) return;
    const on = tEnabled.checked;
    saveSettings({
      interceptDownloads: on,
      interceptVideos: on,
      interceptAudio: on,
      interceptFiles: on,
    });
    applyUiState({
      interceptDownloads: on,
      interceptVideos: on,
      interceptAudio: on,
      interceptFiles: on,
    });
    showToast(on ? "تم تفعيل الاعتراض" : "تم إيقاف الاعتراض");
  });
}

function onPartialToggleChange() {
  if (syncingUi) return;
  const next = {
    interceptDownloads: false,
    interceptVideos: !!tVideo?.checked,
    interceptAudio: !!tAudio?.checked,
    interceptFiles: !!tFiles?.checked,
  };
  saveSettings(next);
  applyUiState(next);
}

if (tVideo) tVideo.addEventListener("change", onPartialToggleChange);
if (tAudio) tAudio.addEventListener("change", onPartialToggleChange);
if (tFiles) tFiles.addEventListener("change", onPartialToggleChange);

// ══════════════════════════════════════════════════════════
//  اتصال KiT Tools
// ══════════════════════════════════════════════════════════
function checkConnection() {
  chrome.runtime.sendNativeMessage(
    "kit.tools.downloader",
    { type: "ping" },
    (resp) => {
      if (chrome.runtime.lastError) {
        dot.className       = "dot";
        statusTxt.textContent = "المضيف غير مسجّل";
      } else if (resp?.pong) {
        dot.className       = "dot ok";
        statusTxt.textContent = "متصل بـ KiT Tools ✔";
      } else {
        dot.className       = "dot";
        statusTxt.textContent = "KiT Tools غير مشغّل";
      }
    }
  );
}

function showToast(msg, isErr = false) {
  toast.textContent = msg;
  toast.className   = isErr ? "show err" : "show";
  setTimeout(() => toast.className = "", 2200);
}

// التشغيل
checkConnection();
