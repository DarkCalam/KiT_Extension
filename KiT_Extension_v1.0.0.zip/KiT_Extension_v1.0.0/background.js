// ═══════════════════════════════════════════════════════════
//  KiT Tools Downloader — Background Service Worker
//  يعترض كل تحميل يبدأه Chrome تلقائياً مثل IDM
// ═══════════════════════════════════════════════════════════

const NATIVE_HOST = "kit.tools.downloader";
const latestMediaByTab = new Map();
let debugMode = false;

// ══════════════════════════════════════════════════════════════
//  ١. الإعدادات (محفوظة في chrome.storage.local)
// ══════════════════════════════════════════════════════════════

// كل أنواع الاعتراض مُفعَّلة دائماً افتراضياً
const settings = {
  interceptDownloads : true,
  interceptVideos    : true,
  interceptFiles     : true,
  interceptAudio     : true,
  debug              : false,
};

function dbg(...args) {
  if (!debugMode) return;
  console.log("[KiTExt]", ...args);
}

// تحميل الإعدادات المحفوظة عند إيقاظ الـ Service Worker
const settingsReady = new Promise((resolve) => {
  chrome.storage.local.get(Object.keys(settings), (stored) => {
    if (!chrome.runtime.lastError) {
      for (const key of Object.keys(settings)) {
        if (typeof stored[key] === "boolean") settings[key] = stored[key];
      }
      debugMode = !!settings.debug;
    }
    resolve();
  });
});

// ══════════════════════════════════════════════════════════════
//  ٢. أنواع الملفات التي نعترضها
// ══════════════════════════════════════════════════════════════

const VIDEO_EXTS = new Set([
  "mp4","mkv","avi","mov","wmv","flv","webm","m4v","ts","m2ts","vob"
]);
const AUDIO_EXTS = new Set([
  "mp3","aac","flac","wav","ogg","m4a","opus","wma"
]);
const FILE_EXTS = new Set([
  "zip","rar","7z","tar","gz","bz2","xz","iso","img",
  "exe","msi","apk","dmg","deb","rpm","pkg"
]);
const STREAM_EXTS = new Set(["m3u8","mpd"]);

const VIDEO_MIMES = ["video/","audio/"];
const FILE_MIMES  = [
  "application/zip","application/x-rar","application/x-7z-compressed",
  "application/x-tar","application/gzip","application/octet-stream",
  "application/vnd.android.package-archive","application/x-apple-diskimage",
  "application/x-msdownload","application/x-msi"
];

function getExt(url) {
  try {
    const path = new URL(url).pathname.toLowerCase();
    const last = path.split("/").pop() || "";
    if (!last.includes(".")) return "";
    return last.split(".").pop();
  } catch { return ""; }
}

function shouldIntercept(url, mime = "") {
  if (!url || !url.startsWith("http")) return false;
  // عند تفعيل الاعتراض العام: اعترض التنزيلات المحتملة فقط (وليس كل http)
  if (settings.interceptDownloads) {
    const ext = getExt(url);
    mime = mime.toLowerCase();
    if (VIDEO_EXTS.has(ext) || STREAM_EXTS.has(ext) || AUDIO_EXTS.has(ext) || FILE_EXTS.has(ext)) return true;
    if (VIDEO_MIMES.some(m => mime.startsWith(m))) return true;
    if (FILE_MIMES.some(m => mime === m)) return true;
    return false;
  }

  const ext = getExt(url);
  mime = mime.toLowerCase();

  if (settings.interceptVideos && (VIDEO_EXTS.has(ext) || STREAM_EXTS.has(ext)))  return true;
  if (settings.interceptAudio  && AUDIO_EXTS.has(ext))                             return true;
  if (settings.interceptFiles  && FILE_EXTS.has(ext))                              return true;
  if (settings.interceptVideos && VIDEO_MIMES.some(m => mime.startsWith(m)))       return true;
  if (settings.interceptFiles  && FILE_MIMES.some(m => mime === m))                return true;

  return false;
}

function isExtensionEnabled() {
  return !!(
    settings.interceptDownloads
    || settings.interceptVideos
    || settings.interceptAudio
    || settings.interceptFiles
  );
}

function rememberMediaRequest(details) {
  try {
    const url = details?.url || "";
    if (!url || !url.startsWith("http")) return;
    if (details.tabId == null || details.tabId < 0) return;

    const host = new URL(url).hostname.toLowerCase();
    const isTikTokMediaHost =
      host.includes("tiktokcdn") ||
      host.includes("byteoversea") ||
      host.includes("ibyteimg") ||
      host.includes("muscdn");
    const ext = getExt(url);
    const isMediaExt = VIDEO_EXTS.has(ext) || AUDIO_EXTS.has(ext) || STREAM_EXTS.has(ext);
    const mime = (details?.responseHeaders || [])
      .find(h => String(h.name || "").toLowerCase() === "content-type")?.value?.toLowerCase() || "";
    const isMediaMime = mime.startsWith("video/") || mime.startsWith("audio/");

    if (!isTikTokMediaHost && !isMediaExt && !isMediaMime) return;
    latestMediaByTab.set(details.tabId, { url, ts: Date.now() });
  } catch { }
}

// ══════════════════════════════════════════════════════════════
//  ٣. اعتراض التحميلات (مثل IDM تماماً)
// ══════════════════════════════════════════════════════════════

chrome.downloads.onCreated.addListener((item) => {
  if (!settings.interceptDownloads) return;

  const url  = item.finalUrl || item.url || "";
  const mime = item.mime     || "";

  if (!shouldIntercept(url, mime)) return;

  // إرسال أولاً، ثم الإلغاء فقط إذا نجح الإرسال — يمنع ضياع التحميل عند تعطل KiT
  sendToKiT(url, "auto-intercept", item.filename).then((sent) => {
    if (!sent) {
      dbg("Fallback to browser download", url);
      return;
    }
    chrome.downloads.cancel(item.id, () => {
      if (chrome.runtime.lastError) return;
      chrome.downloads.erase({ id: item.id }, () => {
        void chrome.runtime.lastError;
      });
    });
  });
});

chrome.webRequest.onBeforeRequest.addListener(
  (details) => rememberMediaRequest(details),
  { urls: ["<all_urls>"], types: ["media", "xmlhttprequest"] }
);

chrome.webRequest.onHeadersReceived.addListener(
  (details) => rememberMediaRequest(details),
  { urls: ["<all_urls>"], types: ["media", "xmlhttprequest"] },
  ["responseHeaders"]
);

chrome.tabs.onRemoved.addListener((tabId) => {
  latestMediaByTab.delete(tabId);
});

// ══════════════════════════════════════════════════════════════
//  ٤. قوائم السياق
// ══════════════════════════════════════════════════════════════

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "kit-link",  title: "تحميل بـ KiT-Tools",        contexts: ["link"]
  });
  chrome.contextMenus.create({
    id: "kit-media", title: "تحميل الوسائط بـ KiT-Tools", contexts: ["video","audio","image"]
  });
  chrome.contextMenus.create({
    id: "kit-page",  title: "تحميل الصفحة بـ KiT-Tools", contexts: ["page"]
  });
});

chrome.contextMenus.onClicked.addListener((info) => {
  const url = info.linkUrl || info.srcUrl || info.pageUrl;
  if (url) sendToKiT(url, "context-menu");
});

// ══════════════════════════════════════════════════════════════
//  ٥. رسائل من content.js و popup.js
// ══════════════════════════════════════════════════════════════

chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  if (msg.type === "get-latest-media") {
    const tabId = sender?.tab?.id;
    const row = tabId != null ? latestMediaByTab.get(tabId) : null;
    const maxAgeMs = 180000;
    const fresh = row && (Date.now() - row.ts <= maxAgeMs);
    respond({ ok: true, url: fresh ? row.url : "" });
    return true;
  }

  if (msg.type === "download") {
    if (!isExtensionEnabled()) {
      respond({ ok: false, disabled: true });
      return true;
    }
    sendToKiT(msg.url, "content-script", msg.title || "");
    respond({ ok: true });
    return true;
  }

  if (msg.type === "get-settings") {
    settingsReady.then(() => respond({ settings }));
    return true;
  }

  if (msg.type === "set-settings") {
    Object.assign(settings, msg.settings);
    debugMode = !!settings.debug;
    chrome.storage.local.set(msg.settings);
    respond({ ok: true });
    return true;
  }

  return true;
});

// ══════════════════════════════════════════════════════════════
//  ٦. إرسال لـ Native Host (KiT Tools)
// ══════════════════════════════════════════════════════════════

function sendToKiT(url, source, title) {
  return new Promise((resolve) => {
    chrome.runtime.sendNativeMessage(
      NATIVE_HOST,
      { url, source, title: title || "" },
      (response) => {
        if (chrome.runtime.lastError) {
          showNotification("⚠️ KiT غير متاح", "سيستمر التحميل عبر المتصفح");
          resolve(false);
          return;
        }
        if (response?.success) {
          const name = title
            || decodeURIComponent(url.split("/").pop()?.split("?")[0] || url).substring(0, 50);
          showNotification("أُضيف للتحميل", name);
          resolve(true);
          return;
        }

        showNotification("⚠️ تعذر الإرسال", "سيستمر التحميل عبر المتصفح");
        resolve(false);
      }
    );
  });
}

function showNotification(title, message) {
  chrome.notifications.create({
    type: "basic", iconUrl: "icons/icon48.png", title, message
  });
}
