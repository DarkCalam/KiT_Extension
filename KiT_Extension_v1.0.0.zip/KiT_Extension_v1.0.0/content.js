// ═══════════════════════════════════════════════════════════
//  KiT Tools Downloader — Content Script
// ═══════════════════════════════════════════════════════════

(function () {
  "use strict";

  // ── المواقع المعروفة (نستخدم رابط الصفحة + لا نضع زر inline) ──
  const KNOWN_VIDEO_SITES = [
    /^https?:\/\/(www\.)?youtube\.com\/watch/,
    /^https?:\/\/youtu\.be\//,
    /^https?:\/\/(www\.)?instagram\.com\/(p|reel|reels)(\/|$)/,
    /^https?:\/\/(www\.)?tiktok\.com\/@.+\/video\//,
    /^https?:\/\/(twitter|x)\.com\/.+\/status\//,
    /^https?:\/\/(www\.)?facebook\.com\/watch/,
    /^https?:\/\/(www\.)?twitch\.tv\/videos\//,
    /^https?:\/\/(www\.)?vimeo\.com\/\d+/,
    /^https?:\/\/(www\.)?dailymotion\.com\/video\//,
    /^https?:\/\/(www\.)?reddit\.com\/r\/.+\/comments\//,
  ];

  const isKnownVideoSite = () => KNOWN_VIDEO_SITES.some(r => r.test(location.href));
  const isYouTube        = () => /youtube\.com|youtu\.be/.test(location.host);
  const isInstagramHost  = () => /(^|\.)instagram\.com$/i.test(location.hostname);
  const isTikTokHost     = () => /(^|\.)tiktok\.com$/i.test(location.hostname);
  const IG_REEL_PATH_RE  = /\/reels?(?:\/|$)/i;
  const IG_STORY_PATH_RE = /\/stories(?:\/|$)/i;
  const isInstagramStoriesPage = () =>
    isInstagramHost() && IG_STORY_PATH_RE.test(location.pathname);
  const isInstagramReelLink = (href = "") => {
    if (!isInstagramHost()) return false;
    try {
      const p = new URL(href, location.origin).pathname;
      return IG_REEL_PATH_RE.test(p);
    } catch {
      return false;
    }
  };

  // ── امتدادات الروابط المباشرة ─────────────────────────────
  // ملاحظة: نُبقي هذه القائمة متوافقة مع VIDEO_EXTS+AUDIO_EXTS+FILE_EXTS في background.js
  // المستندات (pdf/doc/...) مُستثناة عمداً لأن المتصفح يفتحها داخلياً ولا نريد اعتراضها.
  const EXT_SET = new Set([
    // فيديو
    "mp4","mkv","avi","mov","wmv","flv","webm","m4v","ts","m2ts","vob",
    // صوت
    "mp3","aac","flac","wav","ogg","m4a","opus","wma",
    // أرشيفات وبرامج
    "zip","rar","7z","tar","gz","bz2","xz","iso","img",
    "exe","msi","apk","dmg","deb","rpm","pkg"
  ]);

  // ══════════════════════════════════════════════════════════
  //  العنوان الحقيقي للفيديو
  // ══════════════════════════════════════════════════════════
  function getVideoTitle() {
    if (isYouTube()) {
      const sel = [
        "h1.ytd-watch-metadata yt-formatted-string",
        "h1.title yt-formatted-string",
        "ytd-watch-metadata h1",
        "h1.style-scope.ytd-watch-metadata",
      ];
      for (const s of sel) {
        const el = document.querySelector(s);
        if (el?.textContent?.trim()) return el.textContent.trim();
      }
    }
    // Instagram / TikTok / X — meta tags
    const og = document.querySelector('meta[property="og:title"]');
    if (og?.content) return og.content.trim();

    return (document.title || "").replace(/ - YouTube$/, "").trim() || "فيديو";
  }

  // ══════════════════════════════════════════════════════════
  //  الزر العائم (واحد فقط، رابط الصفحة)
  // ══════════════════════════════════════════════════════════
  let floatEl = null, isDragging = false, dragOX = 0, dragOY = 0;
  let igReelFabEl = null;
  let igReelFabLastFireTs = 0;
  let socialFabRafId = 0;
  let currentUrl = "", currentTitle = "";
  let floatDismissedForUrl = "";
  let extensionEnabled = true;

  function scheduleSocialFabUpdate() {
    if (!extensionEnabled) return;
    if (!isInstagramHost() && !isTikTokHost()) return;
    if (socialFabRafId) return;
    socialFabRafId = requestAnimationFrame(() => {
      socialFabRafId = 0;
      ensureInstagramReelFab();
    });
  }

  function buildFloat() {
    if (floatEl) return;
    floatEl = document.createElement("div");
    floatEl.id = "__kit-idm";
    floatEl.setAttribute("role", "toolbar");
    floatEl.setAttribute("aria-label", "تحميل KiT Tools");
    floatEl.innerHTML = `
      <button type="button" class="__kit-ico" aria-label="تحميل هذا الفيديو">▶</button>
      <button type="button" class="__kit-lbl" aria-label="تحميل هذا الفيديو">تحميل هذا الـ فيديو</button>
      <button type="button" class="__kit-x" aria-label="إغلاق" title="إغلاق">✕</button>
    `;

    floatEl.querySelector(".__kit-x").addEventListener("click", (e) => {
      e.stopPropagation();
      floatDismissedForUrl = location.href;
      floatEl.style.display = "none";
    });

    floatEl.querySelector(".__kit-ico").addEventListener("click", download);
    floatEl.querySelector(".__kit-lbl").addEventListener("click", download);

    floatEl.addEventListener("mousedown", (e) => {
      if (e.target.classList.contains("__kit-x")) return;
      isDragging = true;
      dragOX = e.clientX - floatEl.getBoundingClientRect().left;
      dragOY = e.clientY - floatEl.getBoundingClientRect().top;
      floatEl.style.cursor = "grabbing";
      e.preventDefault();
    });

    document.addEventListener("mousemove", (e) => {
      if (!isDragging) return;
      const r = floatEl.getBoundingClientRect();
      const maxX = window.innerWidth  - r.width;
      const maxY = window.innerHeight - r.height;
      const nx = Math.max(0, Math.min(maxX, e.clientX - dragOX));
      const ny = Math.max(0, Math.min(maxY, e.clientY - dragOY));
      floatEl.style.left = nx + "px";
      floatEl.style.top  = ny + "px";
    });

    document.addEventListener("mouseup", () => {
      isDragging = false;
      if (floatEl) floatEl.style.cursor = "grab";
    });

    document.body.appendChild(floatEl);
  }

  function showFloat(url, title) {
    if (!extensionEnabled) return;
    if (floatDismissedForUrl && floatDismissedForUrl === location.href) return;
    buildFloat();
    currentUrl   = url;
    currentTitle = title;
    const lbl    = floatEl.querySelector(".__kit-lbl");
    lbl.textContent = title.length > 40 ? title.substring(0, 40) + "…" : title;
    lbl.title       = title;
    floatEl.style.display = "flex";
  }

  function download() {
    if (!currentUrl) return;
    chrome.runtime.sendMessage({ type: "download", url: currentUrl, title: currentTitle });
    const lbl = floatEl.querySelector(".__kit-lbl");
    const old = lbl.textContent;
    lbl.textContent = "✔ أُضيف للتحميل";
    setTimeout(() => lbl.textContent = old, 1800);
  }

  function findActiveReelVideo() {
    const vids = Array.from(document.querySelectorAll("video"));
    if (!vids.length) return null;

    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const cx = vw / 2;
    const cy = vh / 2;

    let best = null;
    let bestScore = -1;

    for (const v of vids) {
      const r = v.getBoundingClientRect();
      if (r.width < 120 || r.height < 180) continue;

      const ix = Math.max(0, Math.min(r.right, vw) - Math.max(r.left, 0));
      const iy = Math.max(0, Math.min(r.bottom, vh) - Math.max(r.top, 0));
      const visibleArea = ix * iy;
      if (visibleArea <= 0) continue;

      const containsCenter = (cx >= r.left && cx <= r.right && cy >= r.top && cy <= r.bottom) ? 1 : 0;
      const score = visibleArea + (containsCenter * 1000000000);
      if (score > bestScore) {
        bestScore = score;
        best = { video: v, rect: r };
      }
    }

    return best;
  }

  function getInstagramActiveVideoUrl(videoEl) {
    if (!videoEl) return location.href;
    const article = videoEl.closest("article");
    const scoped = article || videoEl.parentElement || document;
    const a = scoped.querySelector('a[href*="/reel/"], a[href*="/reels/"], a[href*="/p/"], a[href*="/tv/"]');
    if (!a?.href) return location.href;
    try {
      return new URL(a.href, location.origin).href;
    } catch {
      return location.href;
    }
  }

  function getTikTokActiveVideoUrl(videoEl) {
    const normalizeTikTokVideoUrl = (rawUrl) => {
      if (!rawUrl) return "";
      try {
        const u = new URL(rawUrl, location.origin);
        if (!/(^|\.)tiktok\.com$/i.test(u.hostname)) return "";
        const m = u.pathname.match(/(\/@[^/]+\/video\/\d+)/i) || u.pathname.match(/(\/video\/\d+)/i);
        if (!m) return "";
        return `${u.origin}${m[1]}`;
      } catch {
        return "";
      }
    };

    // 1) إذا رابط الصفحة نفسه فيديو TikTok استخدمه
    const pageVideoUrl = normalizeTikTokVideoUrl(location.href);
    if (pageVideoUrl) return pageVideoUrl;

    // 2) جرّب ضمن حاوية الفيديو النشط أولاً
    const scoped =
      videoEl?.closest('[data-e2e="recommend-list-item-container"], article, [data-e2e]') ||
      videoEl?.parentElement ||
      document;
    const scopedAnchor = scoped.querySelector('a[href*="/video/"]');
    const scopedVideoUrl = normalizeTikTokVideoUrl(scopedAnchor?.href || "");
    if (scopedVideoUrl) return scopedVideoUrl;

    // 3) جرّب أي رابط فيديو على الصفحة
    const globalAnchor = document.querySelector('a[href*="/video/"]');
    const globalVideoUrl = normalizeTikTokVideoUrl(globalAnchor?.href || "");
    if (globalVideoUrl) return globalVideoUrl;

    // 4) fallback: canonical / og:url
    const canonicalHref = document.querySelector('link[rel="canonical"]')?.href || "";
    const canonicalVideoUrl = normalizeTikTokVideoUrl(canonicalHref);
    if (canonicalVideoUrl) return canonicalVideoUrl;

    const ogUrl = document.querySelector('meta[property="og:url"]')?.content || "";
    const ogVideoUrl = normalizeTikTokVideoUrl(ogUrl);
    if (ogVideoUrl) return ogVideoUrl;

    // 5) fallback إضافي: استخرج أي مسار /@user/video/id من سكربتات TikTok
    const scriptNodes = Array.from(document.querySelectorAll("script"));
    for (const s of scriptNodes) {
      const txt = s?.textContent || "";
      if (!txt) continue;
      const m = txt.match(/\/@[^/"'\\\s]+\/video\/\d+/i);
      if (!m) continue;
      const fromScript = normalizeTikTokVideoUrl(`${location.origin}${m[0]}`);
      if (fromScript) return fromScript;
    }

    // 6) fallback إضافي: تركيب الرابط من uniqueId + id إذا وُجدا في state JSON
    for (const s of scriptNodes) {
      const txt = s?.textContent || "";
      if (!txt) continue;
      if (!txt.includes("uniqueId") || !txt.includes("\"id\"")) continue;
      const uniqueIdMatch = txt.match(/"uniqueId"\s*:\s*"([^"]+)"/);
      const idMatch = txt.match(/"id"\s*:\s*"(\d{8,})"/);
      if (!uniqueIdMatch || !idMatch) continue;
      const composed = normalizeTikTokVideoUrl(`${location.origin}/@${uniqueIdMatch[1]}/video/${idMatch[1]}`);
      if (composed) return composed;
    }

    // 7) آخر حل
    return location.href;
  }

  function ensureInstagramReelFab() {
    if (!extensionEnabled) {
      if (igReelFabEl) {
        igReelFabEl.remove();
        igReelFabEl = null;
      }
      return;
    }
    if (!isInstagramHost() && !isTikTokHost()) {
      if (igReelFabEl) {
        igReelFabEl.remove();
        igReelFabEl = null;
      }
      return;
    }

    const active = findActiveReelVideo();
    if (!active) {
      if (igReelFabEl) igReelFabEl.style.display = "none";
      return;
    }

    if (!igReelFabEl) {
      igReelFabEl = document.createElement("button");
      igReelFabEl.id = "__kit-ig-reel-fab";
      igReelFabEl.type = "button";
      igReelFabEl.title = isTikTokHost() ? "تحميل هذا الفيديو بـ KiT Tools" : "تحميل هذا الريل بـ KiT Tools";
      igReelFabEl.setAttribute("aria-label", isTikTokHost() ? "تحميل هذا الفيديو بـ KiT Tools" : "تحميل هذا الريل بـ KiT Tools");
      igReelFabEl.textContent = "⬇";

      const absorb = (e) => {
        e.stopPropagation();
        e.stopImmediatePropagation();
      };

      const triggerDownload = (e) => {
        e.preventDefault();
        absorb(e);
        const now = Date.now();
        if (now - igReelFabLastFireTs < 450) return;
        igReelFabLastFireTs = now;

        const title = getVideoTitle() || (isTikTokHost() ? "TikTok" : "Instagram Reel");
        const fallbackUrl = isTikTokHost()
          ? getTikTokActiveVideoUrl(active.video)
          : getInstagramActiveVideoUrl(active.video);

        const sendDownload = (url) => {
          chrome.runtime.sendMessage({
            type: "download",
            url,
            title
          });
        };

        if (isTikTokHost()) {
          // TikTok CDN links غالباً مقيّدة (403). الأفضل دائماً رابط الفيديو الصفحي.
          const pageVideoUrl = getTikTokActiveVideoUrl(active.video);
          const isVideoPage = /\/video\/\d+/i.test(pageVideoUrl);
          const safeUrl = isVideoPage ? pageVideoUrl : location.href;
          sendDownload(safeUrl);
        } else {
          sendDownload(fallbackUrl);
        }

        igReelFabEl.textContent = "✔";
        igReelFabEl.style.background = "#4caf50";
        setTimeout(() => {
          if (!igReelFabEl) return;
          igReelFabEl.textContent = "⬇";
          igReelFabEl.style.background = "";
        }, 1800);
      };

      igReelFabEl.addEventListener("pointerdown", absorb, true);
      igReelFabEl.addEventListener("touchstart", absorb, { capture: true, passive: true });
      igReelFabEl.addEventListener("pointerup", triggerDownload, true);
      igReelFabEl.addEventListener("click", triggerDownload, true);
      document.body.appendChild(igReelFabEl);
    } else if (!igReelFabEl.isConnected) {
      document.body.appendChild(igReelFabEl);
    }

    const size = 34;
    const rightInset = isTikTokHost() ? 14 : 12;
    const bottomInset = isTikTokHost()
      ? 100
      : (isInstagramStoriesPage() ? 64 : 12); // تيكتوك: أعلى لتفادي الشريط السفلي
    const x = Math.max(8, Math.round(active.rect.right - size - rightInset));
    const y = Math.max(8, Math.round(active.rect.bottom - size - bottomInset));
    igReelFabEl.style.setProperty("left", `${x}px`, "important");
    igReelFabEl.style.setProperty("top", `${y}px`, "important");
    igReelFabEl.style.display = "flex";
  }

  // ══════════════════════════════════════════════════════════
  //  زر تحميل على أي ‎<video>‎ في الصفحة (يعمل في كل المواقع)
  // ══════════════════════════════════════════════════════════
  function injectVideoButtons(root) {
    if (!extensionEnabled) return;
    if (isInstagramHost() || isTikTokHost()) return;
    if (isYouTube()) {
      document.querySelectorAll(".__kit-on-video").forEach((btn) => btn.remove());
      return;
    }
    root.querySelectorAll("video").forEach(vid => {
      if (vid.dataset.kitVid) return;
      vid.dataset.kitVid = "1";

      const btn = document.createElement("button");
      btn.type        = "button";
      btn.className   = "__kit-thumb-btn __kit-on-video";
      btn.title       = "تحميل هذا الفيديو بـ KiT Tools";
      btn.setAttribute("aria-label", "تحميل هذا الفيديو بـ KiT Tools");
      btn.textContent = "⬇";
      btn.addEventListener("pointerdown", (e) => {
        e.stopPropagation();
        e.stopImmediatePropagation();
      }, true);
      btn.addEventListener("touchstart", (e) => {
        e.stopPropagation();
        e.stopImmediatePropagation();
      }, { capture: true, passive: false });

      btn.addEventListener("click", (e) => {
        e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();

        // اختر أفضل رابط متاح
        let url = "";
        const src = vid.src || vid.querySelector("source[src]")?.src || "";

        if (src && !src.startsWith("blob:") && !src.startsWith("data:")) {
          url = src;                 // رابط مباشر للفيديو
        } else {
          url = location.href;       // blob/MSE → استخدم رابط الصفحة (يحلّه yt-dlp)
        }

        const title = getVideoTitle();
        chrome.runtime.sendMessage({ type: "download", url, title });

        btn.textContent      = "✔";
        btn.style.background = "#4caf50";
        setTimeout(() => { btn.textContent = "⬇"; btn.style.background = ""; }, 1800);
      }, true);

      // ضع الزر في wrapper يحوي الفيديو
      const parent = vid.parentElement;
      if (!parent) return;
      const cs = getComputedStyle(parent);
      if (cs.position === "static") parent.style.position = "relative";
      parent.appendChild(btn);
    });
  }

  // ══════════════════════════════════════════════════════════
  //  زر تحميل واحد فقط لكل بطاقة فيديو
  //  (YouTube + Instagram + TikTok + Twitter + Facebook + Vimeo + …)
  // ══════════════════════════════════════════════════════════
  const VIDEO_CARD_SELECTORS = [
    // YouTube
    { card: "ytd-rich-item-renderer",         link: 'a#thumbnail[href*="/watch"], a[href*="/shorts/"]', title: "#video-title, h3" },
    { card: "ytd-video-renderer",             link: 'a#thumbnail[href*="/watch"]',                       title: "#video-title, h3" },
    { card: "ytd-compact-video-renderer",     link: 'a#thumbnail[href*="/watch"]',                       title: "#video-title, h3" },
    { card: "ytd-grid-video-renderer",        link: 'a#thumbnail[href*="/watch"]',                       title: "#video-title, h3" },
    { card: "ytd-rich-grid-media",            link: 'a#thumbnail[href*="/watch"]',                       title: "#video-title, h3" },
    { card: "ytd-playlist-video-renderer",    link: 'a#thumbnail[href*="/watch"]',                       title: "#video-title, h3" },
    { card: "ytd-reel-item-renderer",         link: 'a[href*="/shorts/"]',                               title: "#video-title, h3" },
    // Instagram
    { card: "article",                         link: 'a[href*="/reel/"], a[href*="/p/"]',                title: "h1, h2" },
    // TikTok
    { card: '[data-e2e="recommend-list-item-container"]', link: 'a[href*="/video/"]',                    title: '[data-e2e="browse-video-desc"]' },
    // Twitter / X
    { card: "article",                         link: 'a[href*="/status/"]',                              title: 'div[lang]' },
    // Facebook
    { card: '[role="article"]',                link: 'a[href*="/watch/"], a[href*="/videos/"], a[href*="/reel/"]', title: 'h3, h4' },
    // Twitch
    { card: 'article',                         link: 'a[href*="/videos/"]',                              title: 'h3' },
    // Reddit
    { card: 'shreddit-post, [data-testid="post-container"]', link: 'a[href*="/comments/"]',              title: 'h1, h3' },
  ];

  // ── دالة موحّدة لإنشاء زر تحميل على رابط فيديو ──
  // mountTo: "link" → يُلصق الزر على linkEl نفسه (مع !important للـ position/display)
  //          "imageParent" (افتراضي) → يُلصقه على parent الصورة (بحجم الصورة، overflow:visible)
  function attachKitButton(linkEl, getTitle, options = {}) {
    if (!linkEl) return false;
    const { flag = "kitBtn", mountTo = "imageParent", important = false } = options;
    if (linkEl.dataset[flag]) return false;
    linkEl.dataset[flag] = "1";

    const btn = document.createElement("button");
    btn.type        = "button";
    btn.className   = "__kit-thumb-btn";
    btn.title       = "تحميل هذا الفيديو بـ KiT Tools";
    btn.setAttribute("aria-label", "تحميل هذا الفيديو بـ KiT Tools");
    btn.textContent = "⬇";
    if (isInstagramReelLink(linkEl.href)) btn.classList.add("__kit-ig-reel-btn");

    const stopProp = (e) => {
      e.stopPropagation();
      e.stopImmediatePropagation();
    };
    btn.addEventListener("pointerdown", stopProp, true);
    btn.addEventListener("touchstart",  stopProp, { capture: true, passive: false });

    btn.addEventListener("click", (e) => {
      e.preventDefault();
      stopProp(e);

      const fullUrl = new URL(linkEl.href, location.origin).href;
      const t = getTitle() || linkEl.title || linkEl.querySelector("img")?.alt || "فيديو";
      chrome.runtime.sendMessage({ type: "download", url: fullUrl, title: t });

      btn.textContent      = "✔";
      btn.style.background = "#4caf50";
      setTimeout(() => { btn.textContent = "⬇"; btn.style.background = ""; }, 1800);
    }, true);

    const host = mountTo === "link"
      ? linkEl
      : (linkEl.querySelector("img")?.parentElement || linkEl);

    const cs = getComputedStyle(host);
    const setStyle = (k, v) => important
      ? host.style.setProperty(k, v, "important")
      : (host.style[k] = v);
    if (cs.position === "static")   setStyle("position", "relative");
    if (cs.display  === "contents") setStyle("display",  "block");
    if (mountTo !== "link")         host.style.overflow = "visible";
    host.appendChild(btn);
    return true;
  }

  // ── shims خفيفة للحفاظ على نفس الواجهة في باقي الكود ──
  const attachOverlay = (_anchor, linkEl, titleStr) =>
    attachKitButton(linkEl, titleStr, { flag: "kitOverlay", mountTo: "link", important: true });
  const attachBtn = (linkEl, titleStr) =>
    attachKitButton(linkEl, titleStr);

  function injectThumbButtons() {
    if (!extensionEnabled) return;
    if (isInstagramHost() || isTikTokHost()) return;

    if (isYouTube()) {
      // ── (أ) كل عنصر بـ id="thumbnail" ──
      document.querySelectorAll("#thumbnail").forEach(thumb => {
        if (thumb.dataset.kitDone) return;
        const img  = thumb.querySelector("img");
        const link = thumb.tagName === "A"
                   ? thumb
                   : (thumb.querySelector('a[href*="/watch"], a[href*="/shorts/"]')
                      || thumb.closest('a[href*="/watch"], a[href*="/shorts/"]'));
        if (!link?.href || link.href.includes("javascript:")) return;
        thumb.dataset.kitDone = "1";

        const anchor = img?.parentElement || thumb;
        const card = thumb.closest(
          "ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer, " +
          "ytd-grid-video-renderer, ytd-rich-grid-media, ytd-playlist-video-renderer, " +
          "ytd-playlist-panel-video-renderer, ytd-reel-item-renderer, " +
          "ytd-shelf-renderer, yt-lockup-view-model"
        );
        attachOverlay(anchor, link, () =>
          card?.querySelector("#video-title, h3 a, h3 .title, .title")?.textContent?.trim()
          || link.getAttribute("aria-label")
        );
      });

      // ── (ب) كل ‎<img>‎ بحجم thumbnail داخل ‎<a href="/watch">‎ ──
      document.querySelectorAll("img").forEach(img => {
        if (img.dataset.kitImg) return;
        const r = img.getBoundingClientRect();
        if (r.width < 60 || r.height < 40) return;
        if (r.width / r.height > 4 || r.height / r.width > 2.5) return;

        const link = img.closest('a[href*="/watch"], a[href*="/shorts/"]');
        if (!link?.href || link.href.includes("javascript:")) return;

        const anchor = img.parentElement;
        if (!anchor) return;
        if (anchor.dataset.kitOverlay) { img.dataset.kitImg = "1"; return; }

        img.dataset.kitImg = "1";
        const card = link.closest(
          "ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer, " +
          "ytd-grid-video-renderer, ytd-rich-grid-media, ytd-playlist-video-renderer, " +
          "ytd-playlist-panel-video-renderer, ytd-reel-item-renderer, " +
          "ytd-shelf-renderer, yt-lockup-view-model"
        );
        attachOverlay(anchor, link, () =>
          card?.querySelector("#video-title, h3 a, h3 .title, .title")?.textContent?.trim()
          || link.getAttribute("aria-label")
        );
      });
      return;
    }

    // ── 2) Instagram: كل ‎<a>‎ لـ post/reel تحوي صورة ──
    if (location.hostname.includes("instagram.com")) {
      document.querySelectorAll('a[href*="/p/"], a[href*="/reel/"], a[href*="/reels/"], a[href*="/tv/"]').forEach(link => {
        if (link.dataset.kitDone) return;
        if (!link.href || link.href === "#") return;
        const img = link.querySelector("img");
        if (!img) return;
        const r = img.getBoundingClientRect();
        if (r.width < 80 || r.height < 80) return; // تجاهل الأفاتارات
        link.dataset.kitDone = "1";
        attachOverlay(img.parentElement || link, link, () =>
          img.alt || link.getAttribute("aria-label") || "Instagram"
        );
      });
      return;
    }

    // ── 3) TikTok: كل ‎<a>‎ لـ video تحوي صورة ──
    if (location.hostname.includes("tiktok.com")) {
      document.querySelectorAll('a[href*="/video/"]').forEach(link => {
        if (link.dataset.kitDone) return;
        const img = link.querySelector("img");
        if (!img) return;
        const r = img.getBoundingClientRect();
        if (r.width < 80 || r.height < 80) return;
        link.dataset.kitDone = "1";
        attachOverlay(img.parentElement || link, link, () =>
          link.closest('[data-e2e]')?.querySelector('[data-e2e*="desc"], h3, h4')?.textContent?.trim()
          || img.alt || "TikTok"
        );
      });
      return;
    }

    // ── 4) باقي المواقع: حسب الـ patterns ──
    VIDEO_CARD_SELECTORS.forEach(({ card, link, title }) => {
      document.querySelectorAll(card).forEach(cardEl => {
        if (cardEl.dataset.kitCard) return;
        const linkEl = cardEl.querySelector(link);
        if (!linkEl) return;
        if (!linkEl.href || linkEl.href === "#" || linkEl.href.startsWith("javascript:")) return;
        cardEl.dataset.kitCard = "1";

        attachBtn(linkEl, () => {
          const t = title ? cardEl.querySelector(title) : null;
          return t?.textContent?.trim() || t?.title;
        });
      });
    });
  }

  // ══════════════════════════════════════════════════════════
  //  زر ⬇ على الروابط المباشرة فقط (ليس social)
  // ══════════════════════════════════════════════════════════
  function isDirectDownload(href) {
    if (!href || href.startsWith("javascript:") || href.startsWith("#")) return false;
    try {
      const u = new URL(href, location.href);
      const ext = u.pathname.toLowerCase().split(".").pop();
      return EXT_SET.has(ext);
    } catch { return false; }
  }

  // لا نُضيف الزر داخل التعليقات/التذييل/القوائم الجانبية
  function isInsideUnwantedSection(el) {
    return el.closest(
      "ytd-comments, " +              // YouTube comments
      "ytd-comment-renderer, " +
      "tp-yt-paper-listbox, " +       // YouTube menus
      "ytd-popup-container, " +
      "[role='complementary'], " +
      "header, footer, nav, aside"
    );
  }

  function injectDirectLinkButtons(root) {
    if (!extensionEnabled) return;
    if (isKnownVideoSite()) return; // في المواقع المعروفة نعتمد على الزر العائم فقط
    root.querySelectorAll("a[href]").forEach(a => {
      if (a.dataset.kitInjected) return;
      if (!isDirectDownload(a.href))  return;
      if (isInsideUnwantedSection(a)) return;
      a.dataset.kitInjected = "1";
      const btn = document.createElement("button");
      btn.type        = "button";
      btn.className   = "__kit-dl-btn";
      btn.title       = "تحميل بـ KiT Tools";
      btn.setAttribute("aria-label", "تحميل بـ KiT Tools");
      btn.textContent = "⬇";
      btn.addEventListener("click", (e) => {
        e.preventDefault(); e.stopPropagation();
        chrome.runtime.sendMessage({ type: "download", url: a.href });
        btn.textContent = "✔"; btn.style.color = "#4caf50";
        setTimeout(() => { btn.textContent = "⬇"; btn.style.color = ""; }, 2000);
      });
      a.insertAdjacentElement("afterend", btn);
    });
  }

  // ══════════════════════════════════════════════════════════
  //  CSS
  // ══════════════════════════════════════════════════════════
  const style = document.createElement("style");
  style.textContent = `
    /* الزر العائم */
    #__kit-idm {
      position: fixed; top: 64px; left: 10px;
      display: none;
      align-items: center; gap: 6px;
      padding: 5px 10px 5px 8px;
      background: linear-gradient(135deg,#0d5aa7,#1976d2);
      color: #fff;
      font-size: 12px;
      font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
      border-radius: 5px;
      cursor: grab;
      z-index: 2147483647;
      box-shadow: 0 3px 12px rgba(0,0,0,.5);
      user-select: none;
      direction: rtl;
      white-space: nowrap;
      border: 1px solid rgba(255,255,255,.18);
      max-width: 320px;
    }
    #__kit-idm:hover { background: linear-gradient(135deg,#1255a0,#1e88e5); }
    /* buttons inside float — strip native styling */
    #__kit-idm .__kit-ico,
    #__kit-idm .__kit-lbl,
    #__kit-idm .__kit-x {
      background: transparent; border: 0; color: inherit;
      font: inherit; padding: 0; margin: 0;
      cursor: pointer; display: inline-flex; align-items: center;
    }
    #__kit-idm .__kit-ico { font-size:10px; color:#a8d4ff; }
    #__kit-idm .__kit-lbl { font-weight:600; overflow:hidden; text-overflow:ellipsis; max-width:240px; text-align:right; }
    #__kit-idm .__kit-lbl:hover { text-decoration:underline; }
    #__kit-idm .__kit-x   { font-size:10px; color:rgba(255,255,255,.55); padding:1px 3px; border-radius:3px; }
    #__kit-idm .__kit-x:hover { background:rgba(255,255,255,.2); color:#fff; }
    #__kit-idm button:focus-visible { outline:2px solid #fff; outline-offset:1px; border-radius:3px; }

    /* زر thumbnail */
    .__kit-thumb-btn {
      position: absolute !important;
      top: 8px !important;
      right: 8px !important;
      left: auto !important;
      width: 30px !important; height: 30px !important;
      background: rgba(13, 90, 167, .95) !important;
      color: #fff !important;
      font-size: 16px; font-weight: bold;
      display: flex !important; align-items: center; justify-content: center;
      border: 0 !important;
      border-radius: 5px;
      cursor: pointer !important;
      z-index: 2147483647 !important;
      text-decoration: none !important;
      box-shadow: 0 2px 8px rgba(0,0,0,.5);
      transition: background .15s, transform .1s;
      direction: ltr;
      pointer-events: auto !important;
      touch-action: manipulation;
      -webkit-user-select: none;
      font-family: inherit;
      padding: 0;
    }
    .__kit-thumb-btn:focus-visible {
      outline: 2px solid #fff !important;
      outline-offset: 1px;
    }
    .__kit-thumb-btn.__kit-ig-reel-btn {
      top: auto !important;
      bottom: 12px !important;
    }
    .__kit-thumb-btn:hover {
      background: #1976d2 !important;
      transform: scale(1.08);
    }
    .__kit-thumb-btn:active { transform: scale(.94); }

    #__kit-ig-reel-fab {
      position: fixed !important;
      width: 34px !important;
      height: 34px !important;
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      border: 0 !important;
      border-radius: 6px !important;
      background: rgba(13, 90, 167, .96) !important;
      color: #fff !important;
      font-size: 16px !important;
      line-height: 1 !important;
      cursor: pointer !important;
      z-index: 2147483647 !important;
      box-shadow: 0 3px 12px rgba(0,0,0,.45) !important;
      pointer-events: auto !important;
      touch-action: manipulation !important;
      user-select: none !important;
      -webkit-user-select: none !important;
    }
    #__kit-ig-reel-fab:hover { background: #1976d2 !important; }
    #__kit-ig-reel-fab:active { transform: scale(.96); }

    /* زر رابط مباشر (للـ .mp4 .zip فقط) */
    .__kit-dl-btn {
      display:inline-block; margin:0 3px; padding:0 5px;
      font-size:12px; line-height:1.4; border:0; border-radius:4px;
      background:#1565c0dd; color:#fff; cursor:pointer;
      vertical-align:middle; user-select:none;
      z-index:9999; position:relative;
      font-family:inherit;
    }
    .__kit-dl-btn:hover { background:#1e88e5ee; }
    .__kit-dl-btn:focus-visible { outline:2px solid #58a6ff; outline-offset:1px; }
  `;

  // ══════════════════════════════════════════════════════════
  //  المراقبة + التشغيل
  // ══════════════════════════════════════════════════════════
  let lastUrl = "";
  const pendingTitleTimeouts = new Set();

  function clearPendingTitleTimeouts() {
    for (const id of pendingTitleTimeouts) clearTimeout(id);
    pendingTitleTimeouts.clear();
  }

  function refreshFloat() {
    if (!extensionEnabled) {
      if (floatEl) floatEl.style.display = "none";
      return;
    }
    ensureInstagramReelFab();
    const hrefNow = location.href;
    if (isInstagramHost() || isTikTokHost()) {
      lastUrl = hrefNow;
      if (floatEl) floatEl.style.display = "none";
      return;
    }
    if (!isKnownVideoSite()) {
      if (floatEl) floatEl.style.display = "none";
      return;
    }

    const urlChanged = hrefNow !== lastUrl;
    if (urlChanged) floatDismissedForUrl = "";
    lastUrl = hrefNow;

    // عند تغيّر الرابط: حاول الحصول على العنوان بعد تأخيرات متعددة
    // (YouTube قد يحدّث الـ DOM متأخراً)
    if (urlChanged) {
      clearPendingTitleTimeouts();           // ألغِ المحاولات السابقة
      [400, 1000, 2000, 3500].forEach(delay => {
        const id = setTimeout(() => {
          pendingTitleTimeouts.delete(id);
          if (location.href !== lastUrl) return; // غادر الصفحة
          const title = getVideoTitle();
          showFloat(location.href, title);
        }, delay);
        pendingTitleTimeouts.add(id);
      });
    } else if (floatEl && floatEl.style.display !== "none") {
      // نفس الرابط — تحقق فقط من تحديث العنوان إذا تغير
      const newTitle = getVideoTitle();
      if (newTitle && newTitle !== currentTitle) {
        showFloat(location.href, newTitle);
      }
    } else {
      // أول ظهور
      const title = getVideoTitle();
      showFloat(location.href, title);
    }
  }

  // ── راقب تغيّر URL عبر History API (YouTube SPA) ──
  ["pushState", "replaceState"].forEach(m => {
    const orig = history[m];
    history[m] = function () {
      const r = orig.apply(this, arguments);
      setTimeout(refreshFloat, 50);
      return r;
    };
  });
  window.addEventListener("popstate", () => setTimeout(refreshFloat, 50));

  // ── Fast throttled scan: تحديث سريع بدون انتظار idle ──
  let scanScheduled = false;
  let lastScanTs = 0;
  const SCAN_MIN_GAP_MS = 120;

  function scheduleScan() {
    if (scanScheduled) return;
    scanScheduled = true;
    requestAnimationFrame(() => {
      scanScheduled = false;
      if (!extensionEnabled) return;
      const now = Date.now();
      if (now - lastScanTs < SCAN_MIN_GAP_MS) return;
      lastScanTs = now;
      scheduleSocialFabUpdate();
      refreshFloat();
      injectThumbButtons();
      if (!isKnownVideoSite()) {
        injectVideoButtons(document.body);
        injectDirectLinkButtons(document.body);
      }
    });
  }

  const observer = new MutationObserver(scheduleScan);

  function removeAllInjectedUi() {
    if (floatEl) floatEl.style.display = "none";
    if (igReelFabEl) {
      igReelFabEl.remove();
      igReelFabEl = null;
    }
    document.querySelectorAll(".__kit-thumb-btn, .__kit-dl-btn, #__kit-ig-reel-fab").forEach((el) => el.remove());
    document.querySelectorAll("[data-kit-vid], [data-kit-done], [data-kit-img], [data-kit-overlay], [data-kit-btn], [data-kit-injected], [data-kit-card]").forEach((el) => {
      const attrs = ["data-kit-vid","data-kit-done","data-kit-img","data-kit-overlay","data-kit-btn","data-kit-injected","data-kit-card"];
      attrs.forEach((a) => el.removeAttribute(a));
    });
  }

  function computeEnabledFromSettings(s) {
    return !!(s.interceptDownloads || s.interceptVideos || s.interceptAudio || s.interceptFiles);
  }

  function init() {
    document.head?.appendChild(style);
    chrome.storage.local.get(
      {
        interceptDownloads: true,
        interceptVideos: true,
        interceptAudio: true,
        interceptFiles: true,
      },
      (s) => {
        extensionEnabled = computeEnabledFromSettings(s || {});
        if (!extensionEnabled) {
          removeAllInjectedUi();
          return;
        }
        scheduleScan();
      }
    );
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      const relevant = ["interceptDownloads","interceptVideos","interceptAudio","interceptFiles"];
      if (!relevant.some((k) => k in changes)) return;
      const s = {
        interceptDownloads: changes.interceptDownloads?.newValue,
        interceptVideos: changes.interceptVideos?.newValue,
        interceptAudio: changes.interceptAudio?.newValue,
        interceptFiles: changes.interceptFiles?.newValue,
      };
      // undefined يعني لم يتغير هذا المفتاح؛ لذلك نقرأ الحالة الكاملة للتأكد.
      chrome.storage.local.get(
        {
          interceptDownloads: true,
          interceptVideos: true,
          interceptAudio: true,
          interceptFiles: true,
        },
        (full) => {
          extensionEnabled = computeEnabledFromSettings(full || s || {});
          if (!extensionEnabled) {
            removeAllInjectedUi();
            return;
          }
          scheduleScan();
        }
      );
    });
    ensureInstagramReelFab();
    window.addEventListener("scroll", () => {
      scheduleSocialFabUpdate();
    }, { passive: true });
    window.addEventListener("resize", () => {
      scheduleSocialFabUpdate();
    });
    refreshFloat();
    injectThumbButtons();
    if (!isKnownVideoSite()) {
      injectVideoButtons(document.body);
      injectDirectLinkButtons(document.body);
    }
    observer.observe(document.body, { childList: true, subtree: true });

    // فحص احتياطي أخف للمحتوى الكسول مع احترام حالة التبويب.
    // الـ MutationObserver هو الأساس، وهذا فقط كشبكة أمان.
    setInterval(() => {
      if (document.hidden) return;
      scheduleScan();
    }, 1000);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
