# ينشئ أيقونات الإضافة من app.ico الخاص بـ KiT Tools
Add-Type -AssemblyName System.Drawing

$icoPath  = "$PSScriptRoot\..\KiT_Tools\app.ico"
$outDir   = "$PSScriptRoot\icons"

if (-not (Test-Path $icoPath)) {
    Write-Host "[ERROR] app.ico غير موجود في: $icoPath" -ForegroundColor Red
    exit 1
}

New-Item -ItemType Directory -Path $outDir -Force | Out-Null

$sizes = @(16, 48, 128)

foreach ($sz in $sizes) {
    $outFile = "$outDir\icon$sz.png"

    # استخراج أيقونة بالحجم المطلوب أو تغيير الحجم
    $icon    = [System.Drawing.Icon]::ExtractAssociatedIcon($icoPath)
    $bmp     = New-Object System.Drawing.Bitmap($sz, $sz)
    $g       = [System.Drawing.Graphics]::FromImage($bmp)
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.DrawImage($icon.ToBitmap(), 0, 0, $sz, $sz)
    $g.Dispose()
    $bmp.Save($outFile, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    $icon.Dispose()

    Write-Host "[OK] $outFile" -ForegroundColor Green
}

Write-Host ""
Write-Host "الأيقونات جاهزة في: $outDir" -ForegroundColor Cyan
